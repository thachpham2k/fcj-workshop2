package com.workshop.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.workshop.dto.ProductRequest;
import com.workshop.dto.ProductResponse;
import com.workshop.model.Product;
import com.workshop.repository.ProductRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;

    public List<ProductResponse> getAll() {
        return productRepository.findAll()
                .stream()
                .map(product -> ProductResponse.builder()
                        .id(product.getId())
                        .skuCode(product.getSkuCode())
                        .quantity(product.getQuantity())
                        .build())
                .toList();
    }

    public void createProduct(ProductRequest productRequest) {
        // Create new product
        Product product = Product.builder()
                .skuCode(productRequest.getSkuCode())
                .quantity(productRequest.getQuantity())
                .build();
        // Save new product to database
        productRepository.save(product);
    }
}
