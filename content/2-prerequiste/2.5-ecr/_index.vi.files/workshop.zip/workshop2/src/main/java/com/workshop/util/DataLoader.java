package com.workshop.util;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.workshop.model.Product;
import com.workshop.repository.ProductRepository;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final ProductRepository productRepository;
    @Override
    public void run(String... args) throws Exception {
        Product product = Product.builder().skuCode("iphone_15").quantity(12).build();
        Product product2 = Product.builder().skuCode("iphone_15_promax").quantity(10).build();

        productRepository.save(product);
        productRepository.save(product2);
    }
}