docker run -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=workshop -p 5432:5432 --name postgresql -d postgres

docker build -t workshop .

docker run \
    -e POSTGRES_HOST=localhost \
    -e POSTGRES_PORT=5432 \
    -e POSTGRES_DB=workshop \
    -e POSTGRES_USERNAME=postgres \
    -e POSTGRES_PASSWORD=postgres \
    -p 8080:8080 \
    --name workshop \
    -d workshop